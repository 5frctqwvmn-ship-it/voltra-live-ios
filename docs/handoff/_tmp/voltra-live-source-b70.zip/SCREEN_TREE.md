# voltra-live-source-b70 — SwiftUI View / ViewModifier registry

Authoritative list of every `struct ... : View` and `struct ... : ViewModifier` declaration in `VoltraLive/` at commit `2b32bec445c0b48e030d8a344d0a50515d2edf84`.

Format: `<file>:<line>  <Name>  : <Protocol>`

## SwiftUI Views

- `VoltraLive/Demo/DemoModeUI.swift:21`  **DemoBanner**
- `VoltraLive/Demo/DemoModeUI.swift:62`  **DemoModeButton**
- `VoltraLive/Demo/DemoModeUI.swift:94`  **DemoEndSheet**
- `VoltraLive/Logging/Views/DebugView.swift:12`  **DebugView**
- `VoltraLive/Logging/Views/ExerciseDetailView.swift:36`  **ExerciseDetailView**
- `VoltraLive/Logging/Views/ExercisePickerView.swift:217`  **NewExerciseSheet**
- `VoltraLive/Logging/Views/ExercisePickerView.swift:9`  **ExercisePickerView**
- `VoltraLive/Logging/Views/ExerciseStartView.swift:13`  **ExerciseStartView**
- `VoltraLive/Logging/Views/ExportSheet.swift:12`  **ExportSheet**
- `VoltraLive/Logging/Views/LiveCaptureContainer.swift:102`  **LiveCaptureUIPickerSheet**
- `VoltraLive/Logging/Views/LiveCaptureContainer.swift:35`  **LiveCaptureContainer**
- `VoltraLive/Logging/Views/LiveCaptureView.swift:2059`  **SwipeableSetRow**
- `VoltraLive/Logging/Views/LiveCaptureView.swift:53`  **LiveCaptureView**
- `VoltraLive/Logging/Views/LiveCaptureViewV2.swift:78`  **LiveCaptureViewV2**
- `VoltraLive/Logging/Views/LoggingHomeView.swift:13`  **LoggingHomeView**
- `VoltraLive/Logging/Views/ProgressChartView.swift:97`  **ProgressChartView**
- `VoltraLive/Logging/Views/PulseDot.swift:25`  **PulseDot**
- `VoltraLive/Logging/Views/RestTimerView.swift:26`  **RestTimerView**
- `VoltraLive/Logging/Views/SetLogView.swift:9`  **SetLogView**
- `VoltraLive/Logging/Views/V2/ForceChartV2.swift:63`  **ForceChartV2**
- `VoltraLive/Logging/Views/V2/MarqueeText.swift:30`  **MarqueeText**
- `VoltraLive/Logging/Views/V2/ModStepperRowV2.swift:37`  **ModStepperRowV2**
- `VoltraLive/Logging/Views/V2/NestedModRowV2.swift:22`  **NestedModRowV2**
- `VoltraLive/Logging/Views/V2/PulleyAndPlatesBarV3.swift:42`  **PulleyAndPlatesBarV3**
- `VoltraLive/Logging/Views/V2/RestTimerBarV2.swift:31`  **RestTimerBarV2**
- `VoltraLive/Logging/Views/V2/V1RestoreSection.swift:32`  **V1RestoreSection**
- `VoltraLive/Views/CompareStripView.swift:7`  **CompareStripView**
- `VoltraLive/Views/ConnectView.swift:7`  **ConnectView**
- `VoltraLive/Views/ContentView.swift:21`  **ContentView**
- `VoltraLive/Views/DashboardView.swift:8`  **DashboardView**
- `VoltraLive/Views/ForceChartView.swift:20`  **ForceChartView**
- `VoltraLive/Views/HistoryDrawerView.swift:8`  **HistoryDrawerView**
- `VoltraLive/Views/PhaseTileView.swift:7`  **PhaseTileView**
- `VoltraLive/Views/SupersetSwitcherBanner.swift:39`  **SupersetSwitcherBanner**
- `VoltraLive/Views/TileView.swift:7`  **TileView**
- `VoltraLive/Views/UnifiedConnectSheet.swift:31`  **UnifiedConnectSheet**
- `VoltraLive/Views/VoltraUnitHeader.swift:92`  **VoltraUnitHeader**

## SwiftUI ViewModifiers

- `VoltraLive/Demo/DemoModeUI.swift:219`  **DemoModeOverlay**
- `VoltraLive/Views/BuildBadgeOverlay.swift:20`  **BuildBadgeOverlay**

## Notes for the architect

- Cold-launch root: `VoltraLiveApp.body` -> `ContentView` (which itself just hosts `LoggingHomeView`). Global overlays mount in `VoltraLiveApp.swift:104-119` (currently `.buildBadgeOverlay()` via `ContentView` and `.demoModeOverlay()` at the WindowGroup root).
- LIVE capture: `LiveCaptureContainer` routes between `LiveCaptureView` (V1, default) and `LiveCaptureViewV2` based on `@AppStorage liveCaptureUIVersion` + dual-Voltra detection.
- Demo Mode chrome: `DemoBanner`, `DemoModeButton`, `DemoEndSheet`, and `DemoModeOverlay` (modifier) all live in `VoltraLive/Demo/DemoModeUI.swift`.
- Settings: there is no `SettingsView`. Closest analog is `DebugView` in `Logging/Views/`.
- Theme: `VoltraColor` (referenced as `VoltraColor.bg`/`.accent`/etc throughout) is defined in `Views/VoltraTheme.swift`, NOT in `Shared/`.
